/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lms.common.type;

/**
 *
 * @author chae
 */
public enum BookOrderStatus { Requested, RequestCancelled, RequestDenied, Ordered, OrderCancelled, InTransit, Arrived } ;
