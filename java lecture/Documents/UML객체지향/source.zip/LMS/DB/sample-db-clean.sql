delete from SEQUENCE;


delete from BOOK_LIBRARYUSER;

delete from BOOKBORROW;

delete from BOOKITEM;
delete from PERIODICALITEM;
delete from PUBLICATIONITEM;

delete from BOOKORDER;

delete from BOOK;
delete from PERIODICAL;
delete from PUBLICATION;

delete from LIBRARYUSER;