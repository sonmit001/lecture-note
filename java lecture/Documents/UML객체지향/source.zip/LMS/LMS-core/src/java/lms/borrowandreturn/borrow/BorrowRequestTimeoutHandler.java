/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lms.borrowandreturn.borrow;

/**
 *
 * @author chae
 */
public interface BorrowRequestTimeoutHandler {
    public void handle() ;
}
