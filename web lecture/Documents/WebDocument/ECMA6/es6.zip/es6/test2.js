function add(a,b){
  return a+b;
}

console.log(add(1,2));

var arr = [1,2];

console.log(add(arr[0], arr[1]));
console.log(add.call(null,arr[0],arr[1]));
console.log(add.apply(null,arr));
