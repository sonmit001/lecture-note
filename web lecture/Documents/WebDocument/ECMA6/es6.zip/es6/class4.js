class Car {
  constructor(args = []){ //조건 할당
    if(args.length > 0){
      this.doors = args[0];
    } else{
      this.doors = 4;
    }
  }  
}

var car = new Car(5);
console.log(car);

class Bus extends Car {
  constructor(...args){
    super(args); //파라미터를 넘기려면 props를 넣어주어야 한다.
    this.color = 'red';
  }

  // constructor(props){
  //   super(props); //파라미터를 넘기려면 props를 넣어주어야 한다.
  //   this.color = 'red';
  // }
  //constructor는 자동으로 생성된다.

  show(){
    console.log(">" + this.doors);
  }
}

var bus = new Bus(6,4,5);//생성자가 없으면 밀어넣는다.
console.log(bus);
