// function Car(){
//   var a = 1;
//   this.doors = 4;
// }
//
// function Car(){
//   var a = 1;
//   this.doors = 4;
// }

//함수로 만들면 같은 이름의 함수를 덮어쓸수 있다.

// Car.prototype.show = function(){
//   //에러가 난다. 함수인 경우는 호이스팅이 일어나지만 클래스는 아니다.
//   console.log(this.doors);
// }

class Car {
  constructor(){
    var a = 1;
    this.doors = 4;
  }

  show() { //프로토타입으로 추가
    console.log(this.doors+">");
  }

  static open(obj){
    console.log(obj.doors + '개의 문을 엽니다.');
  }
}

Car.prototype.show = function(){
  //함수를 덮어 쓴다. 이렇게 정의해도 상관없다.
  console.log(this.doors+">>");
}


//클래스의 경우에는 에러가 뜬다.

var car = new Car();
console.log(car);
console.log(car.show());
console.log(Car.open(car));
