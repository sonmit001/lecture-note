function Car(){
  var a = 1; //지역변수
  this.doors = 4; // 새로운 객체에 추가할 프로퍼티
}

Car.prototype.show = function(){
  console.log(this.doors);
}

//Car의 공통로직을 배치한다. 자바의 static 자원과 비슷
Car.open = function(obj){
  console.log(obj.doors + '개의 문을 엽니다.');
}

var car = new Car();
console.log(car);
//1. {}
//2. {_proto_:Car.prototype}
//3. {_proto_:Car.prototype}

console.log(car.__proto__ === Car.prototype);
car.doors = 5;
car.show();
Car.open(car);

function carFactory(){
  //새 객체를 만들때 설정작업이 복잡한 경우 유효하다.
  return new Car();
}

var sedan = carFactory();
console.log(sedan);
