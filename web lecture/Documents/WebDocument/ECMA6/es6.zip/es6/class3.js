class Car{
  constructor(){
    var a = 1;
    this.doors = 4;
    this.click = this.click.bind(this); //this 고정
  }

  click(){
    console.log(">"+this.doors); //새로 생성되는 객체의 this를 고정
  };

  // dblClicks = () =>{
  //   console.log(">>"+this.doors);
  // };
}

var car = new Car();
console.log(car);
