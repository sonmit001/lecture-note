this.test = "attached to the module";

console.log(this === global);

var foo = {
 test: "attached to an object"
};
// method 프로퍼티는 메소드이름, 콜백함수를 받아서
// this 가 가리키는 객체에 추가한다.
foo.method = function (name, cb) {
  //foo["bar"] = cb;
 this[name] = cb;
};
foo.method("bar", () => {
 console.log(this.test);
});
// 여러분이 기대한 대로 출력되는가?
foo.bar(); // attached to the module
