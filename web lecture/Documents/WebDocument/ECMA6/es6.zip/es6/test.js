 var arr = [];
//    for(var i=0;i<3;i++){
//      arr.push(function(){
//        console.log(i);
//      })
//    }

  //  for(var i=0;i<3;i++){
  //    arr.push((function(){
  //      var j = i;
  //      return function(){
  //        console.log(j);
  //        }
  //    })());
  //  }

     for(let i=0;i<3;i++){
       arr.push(function(){
         console.log(i);
       })
     }


   console.log('arr[0]:',arr[0]());
   console.log('arr[0]:',arr[1]());
   console.log('arr[0]:',arr[2]());
