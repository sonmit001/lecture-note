function foo(){
  console.log('1',this === foo); //true

  var self = this;

  setTimeout((function(){ //큐로 보내서 다시 데이터를 가져오므로 가장 늦게 출력
    console.log('2',this === foo); //false

    console.log('3',this.a); //undefined
    console.log('4',self.a); //func
  }).bind(this),0);
} // 콜백함수는 } 다 끝난후에 큐에서 꺼내 실행시킨다. 자기 자신의 스코프를 벗어난 변수는 클로저를 생성한다.

foo.a = 'func'; //함수는 객체
foo.call(foo);

//JS 함수는
//1. 생성자          ===> class
//2. 로직처리 후 리턴  ===> 메소드

function add(){
  return this.a + this.b;
}

console.log('5',add());

var obj = {a:1, b:2};

console.log(add.call(obj));

var easyAdd = add.bind(obj);
console.log(typeof easyAdd);
console.log(easyAdd);
