var x1 = function(){
  console.log(this === global);
};

var foo1 = ()=>{
  console.log(this === global); //콜백함수용 빈객체
  return 1;
};

var foo2 = a =>{
  return a;
};

var foo3 = (a,b)=>{
  return (a+b);
};

console.log(x1());
console.log(foo1());
console.log(foo2(2));
console.log(foo3(1,2));
