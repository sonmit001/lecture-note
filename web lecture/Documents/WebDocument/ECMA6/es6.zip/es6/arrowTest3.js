function foo(){
  console.log(this === foo); //true

  var self = this;

  setTimeout(function(){
    console.log(this === foo); //false

    console.log(this.a); //undefined
    console.log(self.a); //func
  },0);
} // 콜백함수는 } 다 끝난후에 큐에서 꺼내 실행시킨다. 자기 자신의 스코프를 벗어난 변수는 클로저를 생성한다.

foo.a = 'func'; //함수는 객체
foo.call(foo);

//JS 함수는
//1. 생성자          ===> class
//2. 로직처리 후 리턴  ===> 메소드
