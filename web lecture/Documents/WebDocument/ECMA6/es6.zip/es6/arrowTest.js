var x = {
  result:0
};

var obj = {
  result:0,
  add:function(a,b){
    this.result= a+b; //함수의 호츌자
  }
};

obj.add(1,2); //this는 obj === obj가 호출자
console.log(obj.result);

var  add = obj.add;
add(2,3); // 이때 this 는 글로벌 === 호출자가 없으므로
add.call(x,2,3);

console.log(x.result);
add.apply(x,[3,4]); //호출자가 x
console.log(x.result);

//this는 함수를 호출할때마다 변한다.

var counter = {
  count : 1,
  func1 : function () { //method
    this.count += 1;
    console.log('func1() this.count: ' + this.count); // func1() this.count: 2
    func2 = function () { //function
      this.count += 1;
      console.log('func2() this.count: ' + this.count); // func2() this.count: 101
      func3 = function () { //function
        this.count += 1;
        console.log('func3() this.count: ' + this.count); // func3() this.count: 102
      }
      func3();
    }
    func2(); //글로벌
  }
};
counter.func1(); //this === counter
